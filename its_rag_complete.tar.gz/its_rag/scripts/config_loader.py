"""
ITS RAG - Configuration Loader
Loads settings from configs/config.env
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load config
CONFIG_PATH = Path(__file__).parent.parent / "configs" / "config.env"
load_dotenv(CONFIG_PATH)


class Config:
    # LLM
    LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "qwen3-8b")
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.1"))
    LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "2048"))

    # Embedding
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    EMBEDDING_DIMENSION = int(os.getenv("EMBEDDING_DIMENSION", "384"))

    # ChromaDB
    CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./data/chroma_db")
    CHROMA_COLLECTION_TICKETS = os.getenv("CHROMA_COLLECTION_TICKETS", "its_tickets")
    CHROMA_COLLECTION_KNOWLEDGE = os.getenv("CHROMA_COLLECTION_KNOWLEDGE", "its_knowledge_base")

    # Retrieval
    RETRIEVAL_TOP_K = int(os.getenv("RETRIEVAL_TOP_K", "20"))
    RERANK_TOP_K = int(os.getenv("RERANK_TOP_K", "5"))
    BM25_WEIGHT = float(os.getenv("BM25_WEIGHT", "0.4"))
    DENSE_WEIGHT = float(os.getenv("DENSE_WEIGHT", "0.6"))
    DUPLICATE_THRESHOLD = float(os.getenv("DUPLICATE_THRESHOLD", "0.82"))

    # Chunking
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "450"))
    CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "50"))

    # Reranker
    RERANKER_MODEL = os.getenv("RERANKER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")

    # Data Paths
    RAW_DATA_DIR = os.getenv("RAW_DATA_DIR", "./data/raw")
    PROCESSED_DATA_DIR = os.getenv("PROCESSED_DATA_DIR", "./data/processed")
    KNOWLEDGE_BASE_DIR = os.getenv("KNOWLEDGE_BASE_DIR", "./data/knowledge_base")


config = Config()
